// FlashBlockTest.swift
//
// Standalone correctness harness for FlashBlock.metal. Loads the .npy fixtures
// produced by Scripts/gen_reference.py, runs both kernels on Metal, and
// compares to the reference tensors with atol = rtol = 1e-2 (matching the
// Triton reference in the FlashBlock repo).
//
// Build:
//   xcrun -sdk macosx metal   -c Sources/FlashBlockMetal/FlashBlock.metal -o FlashBlock.air
//   xcrun -sdk macosx metallib  FlashBlock.air -o FlashBlock.metallib
//   swiftc -O -parse-as-library \
//     Sources/FlashBlockMetal/FlashBlockRunner.swift Tests/FlashBlockTest.swift \
//     -o flashblock_test -framework Metal -framework Foundation
//   ./flashblock_test path/to/FlashBlock.metallib Scripts/fixtures

import Foundation
import Metal

// ---- minimal .npy loader (fp16, fp32, int32, uint32 only) -------------------

enum NPY {
    static func load(_ url: URL) -> (data: Data, shape: [Int], dtype: String) {
        let bytes = try! Data(contentsOf: url)
        precondition(bytes.starts(with: [0x93, 0x4E, 0x55, 0x4D, 0x50, 0x59]), "bad npy magic")
        let major = bytes[6]; _ = major
        let headerLen = Int(bytes[8]) | (Int(bytes[9]) << 8)
        let header = String(data: bytes.subdata(in: 10 ..< 10 + headerLen), encoding: .ascii)!
        // Parse dtype and shape from Python dict-ish header.
        let dtype = extract(header, key: "descr")           // e.g. '<f2'
        let shape = extract(header, key: "shape")           // e.g. (2, 3)
            .replacingOccurrences(of: "(", with: "")
            .replacingOccurrences(of: ")", with: "")
            .split(separator: ",")
            .compactMap { Int($0.trimmingCharacters(in: .whitespaces)) }
        let payload = bytes.subdata(in: (10 + headerLen) ..< bytes.count)
        return (payload, shape, dtype)
    }
    private static func extract(_ h: String, key: String) -> String {
        let pattern = "'\(key)':"
        guard let r = h.range(of: pattern) else { return "" }
        let tail = h[r.upperBound...]
        let start = tail.firstIndex(where: { !$0.isWhitespace })!
        if tail[start] == "'" {
            let end = tail[tail.index(after: start)...].firstIndex(of: "'")!
            return String(tail[tail.index(after: start) ..< end])
        } else { // shape tuple
            let end = tail[start...].firstIndex(of: ")")!
            return String(tail[start ... end])
        }
    }
}

func makeBuffer(_ device: MTLDevice, from url: URL) -> (buf: MTLBuffer, shape: [Int]) {
    let (data, shape, _) = NPY.load(url)
    let buf = device.makeBuffer(length: data.count, options: .storageModeShared)!
    data.withUnsafeBytes { raw in
        memcpy(buf.contents(), raw.baseAddress!, data.count)
    }
    return (buf, shape)
}

func maxAbsDiff(_ a: UnsafePointer<Float16>, _ b: UnsafePointer<Float16>, count: Int) -> Float {
    var m: Float = 0
    for i in 0..<count {
        let d = Float(a[i]) - Float(b[i])
        m = max(m, abs(d))
    }
    return m
}

// ---- main -------------------------------------------------------------------

@main
struct Main {
    static func main() throws {
        let args = CommandLine.arguments
        precondition(args.count == 3, "usage: flashblock_test <metallib> <fixtures_dir>")
        let libURL = URL(fileURLWithPath: args[1])
        let fx = URL(fileURLWithPath: args[2])

        guard let device = MTLCreateSystemDefaultDevice() else { fatalError("no Metal device") }
        print("device: \(device.name)")

        // ---- load fixtures ----
        let (qBuf, qShape) = makeBuffer(device, from: fx.appendingPathComponent("Q.npy"))
        let (kcBuf, _)     = makeBuffer(device, from: fx.appendingPathComponent("K_cur.npy"))
        let (vcBuf, _)     = makeBuffer(device, from: fx.appendingPathComponent("V_cur.npy"))
        let (kpBuf, _)     = makeBuffer(device, from: fx.appendingPathComponent("K_page.npy"))
        let (vpBuf, _)     = makeBuffer(device, from: fx.appendingPathComponent("V_page.npy"))
        let (btBuf, _)     = makeBuffer(device, from: fx.appendingPathComponent("block_tables.npy"))
        let (clBuf, _)     = makeBuffer(device, from: fx.appendingPathComponent("ctx_lens.npy"))
        let (oRefBuf, oShape) = makeBuffer(device, from: fx.appendingPathComponent("O_full_ref.npy"))

        // meta.json parse
        let meta = try JSONSerialization.jsonObject(with:
            Data(contentsOf: fx.appendingPathComponent("meta.json"))) as! [String: Any]
        let numSeqs   = meta["num_seqs"]     as! Int
        let blockLen  = meta["block_len"]    as! Int
        let numQHeads = meta["num_q_heads"]  as! Int
        let numKVHds  = meta["num_kv_heads"] as! Int
        let headDim   = meta["head_dim"]     as! Int
        let pageSize  = meta["page_size"]    as! Int
        let maxPages  = meta["max_pages"]    as! Int
        precondition(qShape == [numSeqs * blockLen, numQHeads, headDim])
        precondition(oShape == qShape)

        let cfg = FlashBlockConfig(
            numSeqs: numSeqs, blockLen: blockLen,
            numQHeads: numQHeads, numKVHeads: numKVHds,
            headDim: headDim, pageSize: pageSize, maxPagesPerSeq: maxPages,
            blockM: max(16, blockLen), blockN: 128,
            tau: 4, composeGamma: 0
        )
        let runner = try FlashBlockRunner(device: device, libraryURL: libURL, config: cfg)
        runner.kCache = kpBuf
        runner.vCache = vpBuf
        runner.blockTables = btBuf
        runner.ctxLens = clBuf

        // ---- output buffer ----
        let outBytes = qShape.reduce(1, *) * MemoryLayout<Float16>.size
        let outBuf = device.makeBuffer(length: outBytes, options: .storageModeShared)!

        // ---- Test 1: refreshCache path == full attention ----
        do {
            let cb = runner.queue.makeCommandBuffer()!
            runner.encode(commandBuffer: cb, kind: .refreshCache,
                          Q: qBuf, Kcur: kcBuf, Vcur: vcBuf, output: outBuf)
            cb.commit(); cb.waitUntilCompleted()

            let got = outBuf.contents().bindMemory(to: Float16.self, capacity: qShape.reduce(1,*))
            let ref = oRefBuf.contents().bindMemory(to: Float16.self, capacity: qShape.reduce(1,*))
            let d = maxAbsDiff(got, ref, count: qShape.reduce(1,*))
            print(String(format: "[refresh]  max|got - full_ref| = %.3e  (tol 1e-2)", d))
            precondition(d < 1e-2, "refresh path exceeds tolerance")
        }

        // ---- Test 2: reuseCache path composes using (A_out, L_out) that were
        // just written by Test 1's dispatch, so the composed output should also
        // equal the full reference. ----
        do {
            let cb = runner.queue.makeCommandBuffer()!
            runner.encode(commandBuffer: cb, kind: .reuseCache,
                          Q: qBuf, Kcur: kcBuf, Vcur: vcBuf, output: outBuf,
                          useDirtyGate: false)
            cb.commit(); cb.waitUntilCompleted()

            let got = outBuf.contents().bindMemory(to: Float16.self, capacity: qShape.reduce(1,*))
            let ref = oRefBuf.contents().bindMemory(to: Float16.self, capacity: qShape.reduce(1,*))
            let d = maxAbsDiff(got, ref, count: qShape.reduce(1,*))
            print(String(format: "[reuse]    max|got - full_ref| = %.3e  (tol 1e-2)", d))
            precondition(d < 1e-2, "reuse path exceeds tolerance")
        }

        print("all tests passed")
    }
}
