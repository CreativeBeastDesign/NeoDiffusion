#!/usr/bin/env python3
"""
Reference tensors for FlashBlockOpt.metal. Extends gen_reference.py with:
  - RoPE cos/sin tables and RoPE-applied Q, K
  - W_o output-projection matrix and Y = softmax(QK^T)V · W_o
  - kv_write_slots (where current-block K/V should land in the paged cache)

Writes to Scripts/fixtures_opt/.
Sanity check: max|full - compose| verified in fp32.
"""

from __future__ import annotations
import json, math, os
import numpy as np
from pathlib import Path

RNG = np.random.default_rng(0xF1A5B10C)

CFG = dict(
    num_seqs     = 2,
    block_len    = 16,
    num_q_heads  = 8,
    num_kv_heads = 4,
    head_dim     = 64,
    hidden_dim   = 128,
    page_size    = 128,
    max_pages    = 16,
    max_pos      = 1024,
    rope_base_offset = 384,     # first seq's current block starts at position 384
    ctx_lens     = [384, 192],
    rope_theta_base = 10_000.0,
)

FIX = Path(__file__).parent / "fixtures_opt"
FIX.mkdir(exist_ok=True)


def randn_half(shape, scale=0.5):
    return (RNG.standard_normal(shape).astype(np.float32) * scale).astype(np.float16)


def stable_softmax(x):
    m = x.max(axis=-1, keepdims=True)
    e = np.exp(x - m)
    return e / e.sum(axis=-1, keepdims=True), (m.squeeze(-1) + np.log(e.sum(axis=-1)))


def make_rope(max_pos, head_dim, base):
    half_d = head_dim // 2
    pos = np.arange(max_pos)[:, None]
    d = np.arange(half_d)[None, :]
    theta = pos / (base ** (2 * d / head_dim))
    return np.cos(theta).astype(np.float16), np.sin(theta).astype(np.float16)


def rope_apply(x, cos_row, sin_row):
    # x: [..., head_dim] float32; cos/sin: [head_dim/2] float32
    half_d = x.shape[-1] // 2
    x1 = x[..., :half_d]
    x2 = x[..., half_d:]
    c = cos_row.astype(np.float32)
    s = sin_row.astype(np.float32)
    y1 = x1 * c - x2 * s
    y2 = x1 * s + x2 * c
    return np.concatenate([y1, y2], axis=-1)


def main():
    C = CFG
    Ns, B  = C["num_seqs"], C["block_len"]
    Hq, Hk = C["num_q_heads"], C["num_kv_heads"]
    D      = C["head_dim"]
    Hid    = C["hidden_dim"]
    P      = C["page_size"]
    MP     = C["max_pages"]
    kvg    = Hq // Hk

    Nq = Ns * B
    Q     = randn_half((Nq, Hq, D))
    K_cur = randn_half((Nq, Hk, D))
    V_cur = randn_half((Nq, Hk, D))

    max_ctx = max(C["ctx_lens"])
    total_pages = max(64, Ns * ((max_ctx + P - 1) // P))
    K_page = randn_half((total_pages, P, Hk, D))
    V_page = randn_half((total_pages, P, Hk, D))

    block_tables = np.zeros((Ns, MP), dtype=np.uint32)
    next_page = 0
    for s in range(Ns):
        pages = (C["ctx_lens"][s] + P - 1) // P
        for i in range(pages):
            block_tables[s, i] = next_page
            next_page += 1

    ctx_lens = np.array(C["ctx_lens"], dtype=np.int32)

    # kv_write_slots: where the current block's K/V should be written in the
    # paged cache. We append after each seq's current external context.
    # slot = page * P + off, with pages continued from block_tables.
    kv_write_slots = np.full((Ns, B), -1, dtype=np.int32)
    for s in range(Ns):
        base = C["ctx_lens"][s]
        for t in range(B):
            abs_pos = base + t
            page_idx = abs_pos // P
            off      = abs_pos %  P
            # Make sure the block_table has that page reserved.
            if block_tables[s, page_idx] == 0 and page_idx > 0:
                block_tables[s, page_idx] = next_page
                next_page += 1
            # Slot address is (physical_page_id * P + off).
            phys = int(block_tables[s, page_idx])
            kv_write_slots[s, t] = phys * P + off

    cos_tab, sin_tab = make_rope(C["max_pos"], D, C["rope_theta_base"])

    W_o = randn_half((Hq * D, Hid), scale=0.05)

    # --- Reference computation in fp32 ---
    scale = 1.0 / math.sqrt(D)

    O_full     = np.zeros((Nq, Hq, D),   dtype=np.float32)
    A_out_ref  = np.zeros((Nq, Hq, D),   dtype=np.float32)
    L_out_ref  = np.zeros((Nq, Hq),      dtype=np.float32)
    Y_full     = np.zeros((Nq, Hid),     dtype=np.float32)

    for s in range(Ns):
        Nk_ext = C["ctx_lens"][s]

        # Assemble external K/V (raw, un-RoPE'd), then apply RoPE with absolute
        # positions [0, Nk_ext) (external tokens live at absolute positions
        # before the current block, indexed by their original absolute pos).
        pages_needed = (Nk_ext + P - 1) // P
        K_ext = np.zeros((Nk_ext, Hk, D), np.float32)
        V_ext = np.zeros((Nk_ext, Hk, D), np.float32)
        remaining = Nk_ext
        pos_cursor = 0
        for i in range(pages_needed):
            page = int(block_tables[s, i])
            take = min(P, remaining)
            K_ext[pos_cursor:pos_cursor+take] = K_page[page, :take].astype(np.float32)
            V_ext[pos_cursor:pos_cursor+take] = V_page[page, :take].astype(np.float32)
            pos_cursor += take
            remaining -= take
        # Apply RoPE to K_ext using its absolute position.
        for p in range(Nk_ext):
            K_ext[p] = rope_apply(K_ext[p], cos_tab[p], sin_tab[p])

        # Current-block K/V for this seq (raw).
        K_in = K_cur[s*B:(s+1)*B].astype(np.float32)
        V_in = V_cur[s*B:(s+1)*B].astype(np.float32)
        # RoPE with absolute positions starting at rope_base_offset.
        # For seq 1 we still use the same rope_base_offset in this test to
        # keep the fixture simple; a real model would set it per-seq.
        base_off = C["rope_base_offset"]
        for t in range(B):
            K_in[t] = rope_apply(K_in[t], cos_tab[base_off + t], sin_tab[base_off + t])

        Q_seq = Q[s*B:(s+1)*B].astype(np.float32)
        # RoPE for Q rows (same positions as K_in).
        Q_rot = Q_seq.copy()
        for t in range(B):
            Q_rot[t] = rope_apply(Q_rot[t], cos_tab[base_off + t], sin_tab[base_off + t])

        for qh in range(Hq):
            kh = qh // kvg
            q_block = Q_rot[:, qh]                       # [B, D]

            # External-only
            s_ext = (q_block @ K_ext[:, kh].T) * scale   # [B, Nk_ext]
            p_ext, lse_ext = stable_softmax(s_ext)
            A_ext = p_ext @ V_ext[:, kh]
            A_out_ref[s*B:(s+1)*B, qh] = A_ext
            L_out_ref[s*B:(s+1)*B, qh] = lse_ext

            # Internal
            s_in = (q_block @ K_in[:, kh].T) * scale
            p_in, lse_in = stable_softmax(s_in)
            A_in = p_in @ V_in[:, kh]

            # Compose
            m_c = np.maximum(lse_ext, lse_in)
            w_out = np.exp(lse_ext - m_c)
            w_in  = np.exp(lse_in  - m_c)
            denom = w_out + w_in
            A_full_c = (w_out[:, None] * A_ext + w_in[:, None] * A_in) / denom[:, None]

            # Full attention baseline (concat)
            K_all = np.concatenate([K_ext[:, kh], K_in[:, kh]], axis=0)
            V_all = np.concatenate([V_ext[:, kh], V_in[:, kh]], axis=0)
            s_all = (q_block @ K_all.T) * scale
            p_all, _ = stable_softmax(s_all)
            A_full  = p_all @ V_all
            O_full[s*B:(s+1)*B, qh] = A_full

            # Sanity: compose must equal full.
            d = np.abs(A_full - A_full_c).max()
            assert d < 1e-4, f"compose mismatch: {d}"

            # Output projection contribution: Y += A_full · W_o[qh*D:(qh+1)*D, :]
            Y_full[s*B:(s+1)*B] += A_full @ W_o[qh*D:(qh+1)*D, :].astype(np.float32)

    print(f"[gen_ref_opt] Y_full range: [{Y_full.min():.3f}, {Y_full.max():.3f}]")

    # Save
    np.save(FIX/"Q.npy", Q)
    np.save(FIX/"K_cur.npy", K_cur)
    np.save(FIX/"V_cur.npy", V_cur)
    np.save(FIX/"K_page.npy", K_page)
    np.save(FIX/"V_page.npy", V_page)
    np.save(FIX/"block_tables.npy", block_tables)
    np.save(FIX/"ctx_lens.npy", ctx_lens)
    np.save(FIX/"kv_write_slots.npy", kv_write_slots)
    np.save(FIX/"rope_cos.npy", cos_tab)
    np.save(FIX/"rope_sin.npy", sin_tab)
    np.save(FIX/"W_o.npy", W_o)
    np.save(FIX/"O_full_ref.npy",  O_full.astype(np.float16))
    np.save(FIX/"A_out_ref.npy",   A_out_ref)
    np.save(FIX/"L_out_ref.npy",   L_out_ref)
    np.save(FIX/"Y_full_ref.npy",  Y_full.astype(np.float16))
    (FIX/"meta.json").write_text(json.dumps(CFG, indent=2))
    print(f"[gen_ref_opt] wrote to {FIX}")


if __name__ == "__main__":
    main()
