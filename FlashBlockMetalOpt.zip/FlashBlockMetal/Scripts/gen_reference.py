#!/usr/bin/env python3
"""
Generate deterministic FlashBlock reference tensors and dump them as .npy for
consumption by the Swift test harness.

Emits, under ./fixtures/:
    Q.npy K_cur.npy V_cur.npy K_page.npy V_page.npy
    block_tables.npy ctx_lens.npy
    O_full_ref.npy         — full attention (baseline, no cache)
    A_out_ref.npy L_out_ref.npy  — external-only softmax stats (ln domain)
    O_compose_ref.npy      — result of composing A_out with a fresh A_in
    meta.json

Tolerances used by the Swift test:  atol = rtol = 1e-2  (matches the reference
repo's Triton kernel test).
"""

from __future__ import annotations
import json
import math
import os
import numpy as np
from pathlib import Path

RNG = np.random.default_rng(0xF1A5B10C)

# ---- configuration must match FlashBlockConfig in Swift ---------------------
CFG = dict(
    num_seqs      = 2,
    block_len     = 16,     # B
    num_q_heads   = 8,
    num_kv_heads  = 4,      # GQA group = 2
    head_dim      = 64,
    page_size     = 128,
    max_pages     = 16,
    ctx_lens      = [384, 192],   # external context per seq (tokens)
)

FIX = Path(__file__).parent / "fixtures"
FIX.mkdir(exist_ok=True)


def randn_half(shape):
    return (RNG.standard_normal(shape).astype(np.float32) * 0.5).astype(np.float16)


def stable_softmax(x):
    m = x.max(axis=-1, keepdims=True)
    e = np.exp(x - m)
    return e / e.sum(axis=-1, keepdims=True), (m.squeeze(-1) + np.log(e.sum(axis=-1)))


def main():
    C = CFG
    N_seq, B  = C["num_seqs"], C["block_len"]
    Hq, Hk    = C["num_q_heads"], C["num_kv_heads"]
    D         = C["head_dim"]
    P         = C["page_size"]
    MP        = C["max_pages"]
    kv_group  = Hq // Hk

    # ---- tensors ----
    Nq = N_seq * B
    Q     = randn_half((Nq, Hq, D))
    K_cur = randn_half((Nq, Hk, D))
    V_cur = randn_half((Nq, Hk, D))

    max_ctx = max(C["ctx_lens"])
    num_pages_needed = (max_ctx + P - 1) // P
    total_pages = max(64, N_seq * num_pages_needed)
    K_page = randn_half((total_pages, P, Hk, D))
    V_page = randn_half((total_pages, P, Hk, D))

    # Round-robin page assignment.
    block_tables = np.zeros((N_seq, MP), dtype=np.uint32)
    next_page = 0
    for s in range(N_seq):
        pages = (C["ctx_lens"][s] + P - 1) // P
        for i in range(pages):
            block_tables[s, i] = next_page
            next_page += 1

    ctx_lens = np.array(C["ctx_lens"], dtype=np.int32)

    # ---- reference math (fp32 everywhere) ----
    scale = 1.0 / math.sqrt(D)

    O_full     = np.zeros((Nq, Hq, D), dtype=np.float32)
    A_out_ref  = np.zeros((Nq, Hq, D), dtype=np.float32)
    L_out_ref  = np.zeros((Nq, Hq),    dtype=np.float32)  # natural log
    O_compose  = np.zeros((Nq, Hq, D), dtype=np.float32)

    for s in range(N_seq):
        Nk_ext = C["ctx_lens"][s]

        # Gather this seq's external K/V from pages.
        pages_needed = (Nk_ext + P - 1) // P
        K_ext_rows, V_ext_rows = [], []
        remaining = Nk_ext
        for i in range(pages_needed):
            page = block_tables[s, i]
            take = min(P, remaining)
            K_ext_rows.append(K_page[page, :take].astype(np.float32))
            V_ext_rows.append(V_page[page, :take].astype(np.float32))
            remaining -= take
        K_ext = np.concatenate(K_ext_rows, axis=0) if K_ext_rows else np.zeros((0, Hk, D), np.float32)
        V_ext = np.concatenate(V_ext_rows, axis=0) if V_ext_rows else np.zeros((0, Hk, D), np.float32)

        # Current-block K/V for this seq.
        K_in = K_cur[s*B:(s+1)*B].astype(np.float32)
        V_in = V_cur[s*B:(s+1)*B].astype(np.float32)

        for qh in range(Hq):
            kh = qh // kv_group
            q_block = Q[s*B:(s+1)*B, qh].astype(np.float32)      # [B, D]

            # External statistics.
            if K_ext.shape[0] > 0:
                s_ext = (q_block @ K_ext[:, kh].T) * scale        # [B, Nk_ext]
                p_ext, lse_ext = stable_softmax(s_ext)            # p: [B, Nk_ext], lse: [B]
                A_ext = p_ext @ V_ext[:, kh]                       # [B, D]
            else:
                A_ext = np.zeros((B, D), np.float32)
                lse_ext = np.full((B,), -np.inf, np.float32)

            A_out_ref[s*B:(s+1)*B, qh] = A_ext
            L_out_ref[s*B:(s+1)*B, qh] = lse_ext

            # Internal statistics.
            s_in = (q_block @ K_in[:, kh].T) * scale               # [B, B]
            p_in, lse_in = stable_softmax(s_in)
            A_in = p_in @ V_in[:, kh]                              # [B, D]

            # Composition (paper Eq. 8-9), for the "reuse" path.
            m_c = np.maximum(lse_ext, lse_in)
            w_out = np.exp(lse_ext - m_c)
            w_in  = np.exp(lse_in  - m_c)
            denom = w_out + w_in
            A_full_compose = (w_out[:, None] * A_ext + w_in[:, None] * A_in) / denom[:, None]
            O_compose[s*B:(s+1)*B, qh] = A_full_compose

            # Full attention baseline (concat ext + in).
            K_all = np.concatenate([K_ext[:, kh], K_in[:, kh]], axis=0)
            V_all = np.concatenate([V_ext[:, kh], V_in[:, kh]], axis=0)
            s_all = (q_block @ K_all.T) * scale
            p_all, _ = stable_softmax(s_all)
            O_full[s*B:(s+1)*B, qh] = p_all @ V_all

    # Sanity: compose must equal full-attention within fp32 noise.
    diff = np.abs(O_full - O_compose).max()
    print(f"[gen_reference] max|full - compose| = {diff:.2e}")
    assert diff < 1e-4, "compose reference disagrees with dense reference"

    # ---- dump ----
    np.save(FIX / "Q.npy", Q)
    np.save(FIX / "K_cur.npy", K_cur)
    np.save(FIX / "V_cur.npy", V_cur)
    np.save(FIX / "K_page.npy", K_page)
    np.save(FIX / "V_page.npy", V_page)
    np.save(FIX / "block_tables.npy", block_tables)
    np.save(FIX / "ctx_lens.npy", ctx_lens)
    np.save(FIX / "O_full_ref.npy",   O_full.astype(np.float16))
    np.save(FIX / "A_out_ref.npy",    A_out_ref)
    np.save(FIX / "L_out_ref.npy",    L_out_ref)
    np.save(FIX / "O_compose_ref.npy", O_compose.astype(np.float16))
    (FIX / "meta.json").write_text(json.dumps(CFG, indent=2))
    print(f"[gen_reference] wrote fixtures to {FIX}")


if __name__ == "__main__":
    main()
